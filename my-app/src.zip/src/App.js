import logo from './logo.svg';
import './App.css';
import MyRoutes from "./Routes";



function App() {
  return (
    <div className="App container py-3">
      <MyRoutes />
    </div>
  );
}

export default App;
