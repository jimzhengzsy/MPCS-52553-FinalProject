import React from "react";
import StuDashboards from "./StuDashboards";
import TeaDashboards from "./TeaDashboards";
import Sidebar from "./Sidebar";
import GridLayout from "react-grid-layout";

const layout = [
    { i: "content", x: 1, y: 0, w: 4, h: 1, static: true },
    { i: "sidebar", x: 0, y: 0, w: 1, h: 1, static: true }
];


export default function Dashboards(props){
    return(
        <GridLayout layout={layout} cols={5} width={1200}>
            <div key = "sidebar">
                <Sidebar />
            </div>
            <div key = "content">
                <StuDashboards />
            </div>
        </GridLayout>
    );

}