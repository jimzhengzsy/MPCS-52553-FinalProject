import React from "react";
import "./Home.css";

export default function Home() {
  return (
    <div className="Home">
      <div className="lander">
        <h1>Canvas</h1>
        <p className="text-muted">Welcome to Our Final Project</p>
      </div>
    </div>
  );
}