package com.finalproject.mycanvas.users.entity;

import lombok.Data;

@Data
public class NamePair {
    String firstName;
    String lastName;
}
