package com.finalproject.mycanvas.users.entity;

import lombok.Data;

@Data
public class CheckAnswersRequestbody {
    String answers;
    String answer2;
    String answer3;
    Long id;

}
