package com.finalproject.mycanvas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mpcs52553FinalProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mpcs52553FinalProjectApplication.class, args);
	}

}
