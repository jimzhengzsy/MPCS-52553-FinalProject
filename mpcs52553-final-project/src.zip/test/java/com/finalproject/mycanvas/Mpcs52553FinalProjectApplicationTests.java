package com.finalproject.mycanvas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mpcs52553FinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
